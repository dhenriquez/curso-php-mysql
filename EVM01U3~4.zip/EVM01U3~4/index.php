<?php
header('Location: inicio.php');
?>