<main role="main">
	<div class="index">
		<div class="container">
			<div class="titulo row">
				<div class="col-12 text-center">
					<h1 class="display-1"><?php echo $titulo; ?></h1>
					<h4 class="display-4"><?php echo $descripcion; ?></h4>
				</div>
			</div>
		</div>
	</div>
</main><!-- /.container -->