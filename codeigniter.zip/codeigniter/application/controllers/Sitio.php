<?php
defined('BASEPATH') OR exit('Acceso directo no permitido');

class Sitio extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('datos');
	}
	
	public function index(){
				
		$header = array(
			'active' => __FUNCTION__
		);
		
		$data = array(
			'titulo' => '¡Bienvenido!',
			'descripcion' => 'Aquí podrás encontrar información de ocio.'
		);
		
		$this->load->view('header', $header);
		$this->load->view(__FUNCTION__.'_view', $data);
		$this->load->view('footer');
	}
	
	public function youtube(){
				
		$header = array(
			'active' => __FUNCTION__
		);
		
		$youtube = $this->datos->YoutubePopular();
		
		$data = array(
			'titulo' => 'Youtube',
			'descripcion' => 'Los 10 videos más populares del día en Chile desde youtube.',
			'youtube' => $youtube
		);
		
		$this->load->view('header', $header);
		$this->load->view(__FUNCTION__.'_view', $data);
		$this->load->view('footer');
	}
	
	public function clima(){
		
		$header = array(
			'active' => __FUNCTION__
		);
		
		
		$clima = $this->datos->clima();
		
		$data = array(
			'titulo' => 'Clima',
			'descripcion' => 'El pronóstico del clima para hoy en la capital de Chile.',
			'clima' => $clima
		);
		
		$this->load->view('header', $header);
		$this->load->view(__FUNCTION__.'_view', $data);
		$this->load->view('footer');
	}
	
	public function contacto(){
				
		$header = array(
			'active' => __FUNCTION__
		);
		
		$data = array(
			'titulo' => 'Contacto',
			'descripcion' => 'Si necesitas más información sobre nosotros aquí nos puedes escribir.'
		);
		
		$this->load->view('header', $header);
		$this->load->view(__FUNCTION__.'_view', $data);
		$this->load->view('footer');
	}
	
}
?>